// Copyright 2007 - 2021, Alan Antonuk and the rabbitmq-c contributors.
// SPDX-License-Identifier: mit

#ifndef AMQP_THREADS_H
#define AMQP_THREADS_H

#include <pthread.h>

#endif /* AMQP_THREADS_H */
